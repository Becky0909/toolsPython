/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql57
 Source Server Type    : MySQL
 Source Server Version : 50740
 Source Host           : localhost:3307
 Source Schema         : iam

 Target Server Type    : MySQL
 Target Server Version : 50740
 File Encoding         : 65001

 Date: 22/12/2022 19:01:46
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `instanceID` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `extendShadow` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `createdAt` datetime(3) NULL DEFAULT NULL,
  `updatedAt` datetime(3) NULL DEFAULT NULL,
  `status` bigint(20) NULL DEFAULT NULL,
  `nickname` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `password` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `email` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `phone` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL,
  `isAdmin` bigint(20) NULL DEFAULT NULL,
  `loginedAt` datetime(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `instanceID`(`instanceID`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (11, 'user-x3v8jq', 'admin', 'null', '2022-12-22 09:46:28.883', '2022-12-22 09:50:22.170', 1, '00', '$2a$10$NyictgLeTaJymPDzGtpCceSVY78sZH.PO/4VV.NCPCyHoGyKRK2oa', 'test00@gmail.com', '1306280xxxx', 0, '2022-12-22 09:50:22.169');

SET FOREIGN_KEY_CHECKS = 1;
