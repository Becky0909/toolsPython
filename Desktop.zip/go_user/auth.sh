#!/usr/bin/env bash


API_ROOT=.
# 服务器地址
INSECURE_SERVER="172.18.128.1:8080"


Header="-HContent-Type: application/json"
CCURL="curl -f -s -XPOST" # Create
UCURL="curl -f -s -XPUT" # Update
RCURL="curl -f -s -XGET" # Get
DCURL="curl -f -s -XDELETE" # Delete


# 登录.默认用户admin 密码User@2022
${CCURL} "${Header}" "${HeaderBasic}" http://${INSECURE_SERVER}/v1/login \
  -d'{"username":"admin","password":"User@2022"}' |  jq '.token' | sed 's/"//g'


# 上条命令的输出赋值给token
HeaderBasic="-HAuthorization: Bearer ${token}"  # 注意 -H 与 Authorization 间不能有空格，否则解析会有问题

 # 2. 用 admin，如果有 test00、test01 用户先清空
${DCURL} "${Header}" "${HeaderBasic}" http://${INSECURE_SERVER}/v1/users/test00; echo
${DCURL} "${Header}" "${HeaderBasic}" http://${INSECURE_SERVER}/v1/users/test01; echo

# 3. 用 admin，创建 test00、test01 用户
${CCURL} "${Header}" "${HeaderBasic}" http://${INSECURE_SERVER}/v1/users \
  -d'{"metadata":{"name":"test00"},"password":"User@2022","nickname":"00","email":"test00@gmail.com","phone":"1306280xxxx"}'; echo
${CCURL} "${Header}" "${HeaderBasic}" http://${INSECURE_SERVER}/v1/users \
  -d'{"metadata":{"name":"test01"},"password":"User@2022","nickname":"01","email":"test01@gmail.com","phone":"1306280xxxx"}'; echo

# 5. 用 test00，列出所有用户
${RCURL} "${Header}" "${Header00}" "http://${INSECURE_SERVER}/v1/users?offset=0&limit=10"; echo

# 6. 用 test00，获取 test01 用户的详细信息
${RCURL} "${Header}" "${Header00}" http://${INSECURE_SERVER}/v1/users/test01; echo

# 7. 用 test00，修改 test01 用户
${UCURL} "${Header}" "${Header00}" http://${INSECURE_SERVER}/v1/users/test01 \
  -d'{"nickname":"test01_modified","email":"test00_modified@foxmail.com","phone":"1306280xxxx"}'; echo

# 8. 用 test00，删除 test00、test01 用户
${DCURL} "${Header}" "${Header00}" http://${INSECURE_SERVER}/v1/users/test01; echo
${DCURL} "${Header}" "${Header00}" http://${INSECURE_SERVER}/v1/users/test00; echo



