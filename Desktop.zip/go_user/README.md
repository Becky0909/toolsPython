# gin+gorm+gwt用户信息增删改查


## 项目结构
main.go 入口文件
config/config.yaml 配置文件
api_server/config 配置类。初始化配置和数据库
api_server/user/model/v1 模型类
api_server/user/repo  数据库repo。里面封装了gorm的数据库操作方法。增删改查都有。该部分独立于gin，grpc部分可直接调用
api_server/gin/auth.go jwt的相关方法
api_server/gin/router.go gin路由
api_server/controller 路由对应的控制器。处理请求的逻辑代码。

## 如何运行？
1. 新建数据库。然后导入sql文件到数据库。最后正确配置config/config.yaml数据库信息
2. 在项目根目录下运行命令go mod tidy同步依赖
3. 在项目根目录下运行命令go run main.go运行server
4. 使用auth.sh里的命令开始测试


## 如何测试？
复制auth.sh里的命令到终端运行（使用bash测试）




