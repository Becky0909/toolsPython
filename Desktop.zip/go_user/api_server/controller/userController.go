package controller

import (
	"github.com/gin-gonic/gin"
	"github.com/rebirthmonkey/go/pkg/errcode"
	"github.com/rebirthmonkey/go/pkg/errors"
	"github.com/rebirthmonkey/go/pkg/gin/util"
	"github.com/rebirthmonkey/go/pkg/log"
	"go_user/api_server/config"
	model "go_user/api_server/user/model/v1"
	"go_user/api_server/user/repo"
	"golang.org/x/crypto/bcrypt"
	"time"
)

var userRepo = repo.NewUserRepo(config.Db)

var Create = func(c *gin.Context) {
	var user model.User
	// json绑定
	if err := c.ShouldBindJSON(&user); err != nil {
		log.L(c).Errorf("ErrBind: %s\n", err)
		util.WriteResponse(c, errors.WithCode(errcode.ErrBind, err.Error()), nil)

		return
	}
	// 处理密码
	hashedBytes, _ := bcrypt.GenerateFromPassword([]byte(user.Password), bcrypt.DefaultCost)
	user.Password = string(hashedBytes)
	user.Status = 1
	user.LoginedAt = time.Now()

	// 创建用户
	if err := userRepo.Create(&user); err != nil {
		util.WriteResponse(c, err, nil)
		return
	}

	util.WriteResponse(c, nil, user)

}

var List = func(c *gin.Context) {
	users, err := userRepo.List()
	if err != nil {
		util.WriteResponse(c, err, nil)

		return
	}
	util.WriteResponse(c, nil, users)

}

var Delete = func(c *gin.Context) {

	if err := userRepo.Delete(c.Param("name")); err != nil {
		util.WriteResponse(c, err, nil)
		return
	}
	var msg string = "deleted user " + c.Param("name")
	util.WriteResponse(c, nil, msg)
}

var Update = func(c *gin.Context) {
	var user model.User

	if err := c.ShouldBindJSON(&user); err != nil {
		log.L(c).Errorf("ErrBind: %s\n", err)
		util.WriteResponse(c, errors.WithCode(errcode.ErrBind, err.Error()), nil)

		return
	}

	user.Name = c.Param("name")

	if err := userRepo.Update(&user); err != nil {
		util.WriteResponse(c, err, nil)

		return
	}

	util.WriteResponse(c, nil, user)
}

var Get = func(c *gin.Context) {
	user, err := userRepo.Get(c.Param("name"))
	if err != nil {
		util.WriteResponse(c, err, nil)

		return
	}

	util.WriteResponse(c, nil, user)
}
