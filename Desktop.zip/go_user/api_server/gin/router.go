package server

import (
	"fmt"
	"github.com/rebirthmonkey/go/pkg/auth"
	userController "go_user/api_server/controller"

	"github.com/gin-gonic/gin"
	"github.com/rebirthmonkey/go/pkg/gin/middleware"
)

func Init(g *gin.Engine) {
	installRouterMiddleware(g)
	installController(g)
}

func installRouterMiddleware(g *gin.Engine) {
	fmt.Println("[GINServer] registry LoggerMiddleware")
	// 日志
	g.Use(middleware.LoggerMiddleware())
}

// 路由
func installController(g *gin.Engine) *gin.Engine {
	v1 := g.Group("/v1")
	{
		fmt.Println("[GINServer] registry userHandler")
		jwtStrategy, _ := newJWTAuth().(auth.JWTStrategy)
		// 登录 使用jwt登录中间件
		v1.POST("/login", jwtStrategy.LoginHandler)
		userv1 := v1.Group("/users")
		// 使用jwt中间件
		userv1.Use()
		{

			// 创建用户
			userv1.POST("", userController.Create)
			// 删除用户
			userv1.DELETE(":name", userController.Delete)
			// 更新
			userv1.PUT(":name", userController.Update)
			// 获取对应name的用户信息
			userv1.GET(":name", userController.Get)
			// 获取所有用户信息
			userv1.GET("", userController.List)
		}
	}
	return g
}
