package repo

import (
	"github.com/rebirthmonkey/go/pkg/errcode"
	"github.com/rebirthmonkey/go/pkg/errors"
	"github.com/rebirthmonkey/go/pkg/log"
	model "go_user/api_server/user/model/v1"
	"gorm.io/gorm"
	"regexp"
)

// userRepo stores the user's info.
type userRepo struct {
	dbEngine *gorm.DB
}

// 调用此方法可以返回一个userRepo实例。实例通过参数传入的gorm.DB调用下面的增删改查方法
func NewUserRepo(db *gorm.DB) *userRepo {
	return &userRepo{dbEngine: db}

}

// close closes the repo's DB engine.
func (u *userRepo) close() error {
	dbEngine, err := u.dbEngine.DB()
	if err != nil {
		return errors.WithCode(errcode.ErrDatabase, err.Error())
	}

	return dbEngine.Close()
}

// Create creates a new user account.
func (u *userRepo) Create(user *model.User) error {
	tmpUser := model.User{}
	u.dbEngine.Where("name = ?", user.Name).Find(&tmpUser)
	if tmpUser.Name != "" {
		err := errors.WithCode(errcode.ErrRecordAlreadyExist, "the created user already exit")

		log.Errorf("%+v", err)
		return err
	}

	err := u.dbEngine.Create(&user).Error
	if err != nil {
		if match, _ := regexp.MatchString("Duplicate entry", err.Error()); match {
			return errors.WrapC(err, errcode.ErrRecordAlreadyExist, "duplicate entry.")
		}

		return err
	}

	return nil
}

// Delete deletes the user by the user identifier.
func (u *userRepo) Delete(username string) error {
	tmpUser := model.User{}
	u.dbEngine.Where("name = ?", username).Find(&tmpUser)
	if tmpUser.Name == "" {
		err := errors.WithCode(errcode.ErrRecordNotFound, "the delete user not found")
		log.Errorf("%s\n", err)
		return err
	}

	if err := u.dbEngine.Where("name = ?", username).Delete(&model.User{}).Error; err != nil {
		return err
	}

	return nil
}

// Update updates a user account information.
func (u *userRepo) Update(user *model.User) error {
	tmpUser := model.User{}
	u.dbEngine.Where("name = ?", user.Name).Find(&tmpUser)
	if tmpUser.Name == "" {
		err := errors.WithCode(errcode.ErrRecordNotFound, "the update user not found")
		log.Errorf("%s\n", err)
		return err
	}
	user.ID = tmpUser.ID

	if err := u.dbEngine.Save(user).Error; err != nil {
		return err
	}

	return nil
}

// Get returns a user's info by the user identifier.
func (u *userRepo) Get(username string) (*model.User, error) {
	user := &model.User{}
	err := u.dbEngine.Where("name = ?", username).First(&user).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, errors.WithCode(errcode.ErrRecordNotFound, "the get user not found.")
		}

		return nil, errors.WithCode(errcode.ErrDatabase, err.Error())
	}

	return user, nil
}

// List returns all the related users.
func (u *userRepo) List() (*model.UserList, error) {
	ret := &model.UserList{}

	d := u.dbEngine.
		Order("id desc").
		Find(&ret.Items).
		Offset(-1).
		Limit(-1).
		Count(&ret.TotalCount)

	return ret, d.Error
}
