package main

import (
	"github.com/gin-gonic/gin"
	_ "go_user/api_server/config"
	"go_user/api_server/gin"
)

func main() {
	g := gin.Default()
	// 初始化中间件
	server.Init(g)
	// 运行
	g.Run(":8080")

}
